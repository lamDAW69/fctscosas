import { Version } from '@microsoft/sp-core-library';
import { type IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IComponentes1WebPartProps {
    description: string;
    titleListAlumnos: string;
    DARK: boolean;
}
export default class Componentes1WebPart extends BaseClientSideWebPart<IComponentes1WebPartProps> {
    render(): void;
    protected onInit(): Promise<void>;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=Componentes1WebPart.d.ts.map