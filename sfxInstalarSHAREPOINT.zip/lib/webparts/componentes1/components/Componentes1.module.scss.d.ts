declare const styles: {
    componentes1: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=Componentes1.module.scss.d.ts.map