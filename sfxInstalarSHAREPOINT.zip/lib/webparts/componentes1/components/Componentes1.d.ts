import * as React from "react";
import type { IComponentes1Props } from "./IComponentes1Props";
declare const Componentes1: React.FC<IComponentes1Props>;
export default Componentes1;
//# sourceMappingURL=Componentes1.d.ts.map