import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  type IPropertyPaneConfiguration,
  PropertyPaneTextField, PropertyPaneToggle
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'Componentes1WebPartStrings';
import Componentes1 from './components/Componentes1';
import { IComponentes1Props } from './components/IComponentes1Props';

export interface IComponentes1WebPartProps {
  description: string;
  titleListAlumnos: string;
  DARK: boolean;
}

export default class Componentes1WebPart extends BaseClientSideWebPart<IComponentes1WebPartProps> {

  

  public render(): void {
    const element: React.ReactElement<IComponentes1Props> = React.createElement(
      Componentes1,
      {
        description: this.properties.description,
        isDarkTheme: this.properties.DARK,

        hasTeamsContext: !!this.context.sdks.microsoftTeams,
        userDisplayName: this.context.pageContext.user.displayName,
        titleList: this.properties.titleListAlumnos
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onInit(): Promise<void> {
    return super.onInit();
  }







  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                }),
                PropertyPaneTextField('titleListAlumnos', {
                  label: strings.otro
                }),
                PropertyPaneToggle('DARK', {label: "Modo oscuro?",
                checked: false 
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
