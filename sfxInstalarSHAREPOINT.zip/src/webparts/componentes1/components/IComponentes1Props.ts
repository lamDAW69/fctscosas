export interface IComponentes1Props {
  description: string;
  isDarkTheme?: boolean;
  environmentMessage?: string;
  hasTeamsContext: boolean;
  userDisplayName?: string;
  titleList: string; 
}


