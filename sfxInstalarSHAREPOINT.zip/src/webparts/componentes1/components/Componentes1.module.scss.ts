/* tslint:disable */
require("./Componentes1.module.css");
const styles = {
  componentes1: 'componentes1_8fd5d667',
  teams: 'teams_8fd5d667',
  welcome: 'welcome_8fd5d667',
  welcomeImage: 'welcomeImage_8fd5d667',
  links: 'links_8fd5d667'
};

export default styles;
/* tslint:enable */