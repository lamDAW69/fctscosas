import * as React from "react";
import styles from "./Componentes1.module.scss";
import type { IComponentes1Props } from "./IComponentes1Props";
import { DefaultButton } from '@fluentui/react/lib/Button';
import { toInteger } from "lodash";

//import { escape } from '@microsoft/sp-lodash-subset';

const Componentes1: React.FC<IComponentes1Props> = ({
  hasTeamsContext,
  isDarkTheme,
  titleList,
}) => {



  const [contador ,  setContador] = React.useState<number>(0)

  const guardarVoto = () => {
    localStorage.setItem('VOTO-NTT' , '1')
    setContador(1)
  }

  React.useEffect(() => {
if(localStorage.getItem('VOTO-NTT')){
  const Valor:string | null = localStorage.getItem('VOTO-NTT')
  setContador(toInteger(Valor))
}
  }, [])






  return (
    <section
      className={`${styles.componentes1} ${hasTeamsContext ? styles.teams : ""
        }`}
    >
      <div className={styles.welcome}>
        <img
          alt=""
          src={
            isDarkTheme
              ? require("../assets/welcome-dark.png")
              : require("../assets/welcome-light.png")
          }
          className={styles.welcomeImage}
        />
       <h1>{contador}</h1> 
       {contador === 0 &&
       <DefaultButton text="Guardar Voto" onClick={()=> guardarVoto()}/>}

       {/* <PrimaryButton text="sumar + " onClick={()=> setContador(contador +1)}/>
       <DefaultButton text="restar -" onClick={()=> setContador(contador - 1)}/> */}

      </div>
      <div>
        <h3
          style={
            isDarkTheme
              ? { backgroundColor: "gray" }
              : { backgroundColor: "yellow" }
          }
        >
          Titulo de la Lista: {titleList}
        </h3>
       
      
      </div>
    </section>
  );
};

export default Componentes1;
