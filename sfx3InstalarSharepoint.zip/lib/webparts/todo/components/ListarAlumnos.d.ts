import * as React from "react";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
interface IListarAlumnos {
    nombreLista: string;
}
declare const ListarAlumnos: React.FC<IListarAlumnos>;
export default ListarAlumnos;
//# sourceMappingURL=ListarAlumnos.d.ts.map