declare const styles: {
    todo: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=Todo.module.scss.d.ts.map