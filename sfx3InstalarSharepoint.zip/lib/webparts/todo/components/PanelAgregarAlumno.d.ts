import * as React from 'react';
interface IPop {
    refreshList: () => void;
}
export declare const DialogAlumno: React.FunctionComponent<IPop>;
export {};
//# sourceMappingURL=PanelAgregarAlumno.d.ts.map