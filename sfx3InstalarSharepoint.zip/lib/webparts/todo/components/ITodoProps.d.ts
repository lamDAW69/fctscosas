export interface ITodoProps {
    description: string;
}
export interface IListsAlumnos {
    ID?: number;
    DNI: string;
    Nombre: string;
    Apellido: string;
    Edad?: number;
    Foto?: string;
}
//# sourceMappingURL=ITodoProps.d.ts.map