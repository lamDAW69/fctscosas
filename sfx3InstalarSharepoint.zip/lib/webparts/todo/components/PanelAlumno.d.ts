import * as React from "react";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
interface IPanelReact {
    open: boolean;
    data: any[];
    refresh: () => void;
}
export declare const PanelAlumno: React.FC<IPanelReact>;
export {};
//# sourceMappingURL=PanelAlumno.d.ts.map