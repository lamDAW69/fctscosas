import * as React from "react";
import type { ITodoProps } from "./ITodoProps";
declare const Todo: React.FC<ITodoProps>;
export default Todo;
//# sourceMappingURL=Todo.d.ts.map