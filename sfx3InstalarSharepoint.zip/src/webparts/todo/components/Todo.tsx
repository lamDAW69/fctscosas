import * as React from "react";
import type { ITodoProps } from "./ITodoProps";

//LIbrerías pnp
import ListarAlumnos from "./ListarAlumnos";

const Todo: React.FC<ITodoProps> = (props) => {
  const { description } = props;

  return (
    <>
      <ListarAlumnos nombreLista={description} />
    </>
  );
};

export default Todo;
