import * as React from "react";
import { Panel, PanelType } from "@fluentui/react/lib/Panel";
import { useBoolean } from "@fluentui/react-hooks";

import { TextField } from "@fluentui/react";
import { Stack, IStackProps, IStackStyles } from "@fluentui/react/lib/Stack";

import { IIconProps } from "@fluentui/react";
import { ActionButton } from "@fluentui/react";

import { getSP } from "../pnpjsConfig";
import { SPFI } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";

const addFriendIcon: IIconProps = { iconName: "EditContact" };
const deleteFriendIcon: IIconProps = { iconName: "DeleteRows" };
const stackTokens = { childrenGap: 50 };
const stackStyles: Partial<IStackStyles> = { root: { width: 650 } };
const columnProps: Partial<IStackProps> = {
  tokens: { childrenGap: 15 },
  styles: { root: { width: 300 } },
};

const PanelDisplay: React.FunctionComponent<{
  panelType: PanelType;
  open: boolean;
  alumnoData: any[];
  refreshList: () => void;
}> = (props) => {
  const { alumnoData, open, panelType, refreshList } = props;
  const [isOpen, { setTrue: openPanel, setFalse: dismissPanel }] =
    useBoolean(open);
  console.log(alumnoData);
  const _sp: SPFI = getSP();
  const list = _sp.web.lists.getByTitle("Alumnos");

  React.useEffect(() => {
    if (open) {
      openPanel();
    } else {
      dismissPanel();
    }
  }, [open, openPanel, dismissPanel]);

  const [alumno, setAlumno] = React.useState({
    Nombre: "",
    Apellido: "",
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    //Guardar valores nuevos
    const { value, id } = e.target;
    console.log(e.target);
    setAlumno((prevState) => ({
      ...prevState,
      [id.trim()]: value, //trim() elimina espacios en blanco al principio y al final del nombre del campo
    }));
  };

  const handleDelete = async () => {
    const Delete = await list.items
      .getById(alumnoData[0].ID)
      .delete();
    console.log(Delete);
    refreshList();
  };

  React.useEffect(() => {
    //Cargar datos del alumno
    if (alumnoData.length > 0) {
      setAlumno((prevState) => ({
        ...prevState,
        Nombre: alumnoData[0].Nombre,
        Apellido: alumnoData[0].Apellido,
      }));
    }
  }, [alumnoData]);

  const handlerSave = async () => {
    console.log(alumno);

    const update = await list.items.getById(alumnoData[0].ID).update({
      Nombre: alumno.Nombre,
      Apellido: alumno.Apellido,
    });
    console.log(update);
    refreshList();
  };

  return (
    <div>
      <Panel
        isOpen={isOpen}
        onDismiss={dismissPanel}
        type={panelType}
        customWidth={
          panelType === PanelType.custom || panelType === PanelType.customNear
            ? "888px"
            : undefined
        }
        closeButtonAriaLabel="Close"
        headerText="Editar alumno"
      >
        <Stack horizontal tokens={stackTokens} styles={stackStyles}>
          <Stack {...columnProps}>
            <TextField
              id="Nombre"
              label="Nombre"
              defaultValue={alumnoData[0].Nombre}
              onChange={handleChange}
            />
            <TextField
              id="Apellido"
              label="Apellido"
              defaultValue={alumnoData[0].Apellido}
              onChange={handleChange}
            />
            <ActionButton iconProps={addFriendIcon} onClick={handlerSave}>
              Editar datos del alumno
            </ActionButton>
            <ActionButton iconProps={deleteFriendIcon} onClick={handleDelete}>
              Eliminar alumno
            </ActionButton>
          </Stack>
        </Stack>
      </Panel>
    </div>
  );
};

interface IPanelReact {
  open: boolean;
  data: any[];
  refresh: () => void;
}

export const PanelAlumno: React.FC<IPanelReact> = ({ open, data, refresh }) => {
  return (
    <PanelDisplay
      panelType={PanelType.medium}
      open={open}
      alumnoData={data}
      refreshList={refresh}
    />
  );
};
