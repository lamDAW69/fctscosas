/* tslint:disable */
require("./Todo.module.css");
const styles = {
  todo: 'todo_358c980c',
  teams: 'teams_358c980c',
  welcome: 'welcome_358c980c',
  welcomeImage: 'welcomeImage_358c980c',
  links: 'links_358c980c'
};

export default styles;
/* tslint:enable */