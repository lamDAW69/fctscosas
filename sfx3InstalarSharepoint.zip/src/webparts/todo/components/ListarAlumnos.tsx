import * as React from "react";
//  import { IListsAlumnos } from "./ITodoProps";
import { IViewField, ListView, SelectionMode } from "@pnp/spfx-controls-react";

import { PanelAlumno } from "./PanelAlumno";

import { getSP } from "../pnpjsConfig";
import { SPFI } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import { DialogAlumno } from "./PanelAgregarAlumno";



interface IListarAlumnos {
  nombreLista: string;
}

const ListarAlumnos: React.FC<IListarAlumnos> = ({ nombreLista }) => {
  const [isPanelOpen, setIsPanelOpen] = React.useState(false);
  const [item, setItem] = React.useState<any[]>([]);
  console.log(item);
  const _sp: SPFI = getSP();

  const [alumnos, setAlumnos] = React.useState<any>([]);

  async function ReadData() {
    const items: any[] = await _sp.web.lists.getByTitle(nombreLista).items();
    console.log(items);
    setAlumnos(items);
    setIsPanelOpen(false);
  }

  React.useEffect(() => {
    if (!isPanelOpen) {
      ReadData();
    }
  }, []);

  function _getSelection(items: any[]) {
    console.log("Selected items: ", items);
    setItem(items);
    setIsPanelOpen(!isPanelOpen);
  }

  const viewFields: IViewField[] = [
    {
      name: "ID",
      displayName: "ID",
      minWidth: 10,
      maxWidth: 20,
      isResizable: true,
    },
    {
      name: "Nombre",
      displayName: "Nombre",
      minWidth: 100,
      maxWidth: 200,
      isResizable: true,
    },
    {
      name: "Apellido",
      displayName: "Apellido",
      minWidth: 100,
      maxWidth: 200,
      isResizable: true,
    },
    {
      name: "Edad",
      displayName: "Edad",
      minWidth: 10,
      maxWidth: 50,
      isResizable: true,
    },
    {
      name: "Foto",
      displayName: "Foto",
      minWidth: 10,
      maxWidth: 200,
      isResizable: true,
    },
  ];

  return (
    <>
    <DialogAlumno refreshList={ReadData}/>
      <ListView
        items={alumnos}
        viewFields={viewFields}
        iconFieldName="AccountBrowserIcon"
        compact={true}
        selection={_getSelection}
        selectionMode={SelectionMode.single}
        showFilter={true}
        stickyHeader={true}
      />
       {isPanelOpen &&
  <PanelAlumno open={isPanelOpen} data={item} refresh={ReadData}/>
  } 
    </>
  );
};

export default ListarAlumnos;
