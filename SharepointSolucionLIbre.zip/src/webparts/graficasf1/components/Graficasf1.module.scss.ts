/* tslint:disable */
require("./Graficasf1.module.css");
const styles = {
  graficasf1: 'graficasf1_88ddd40a',
  teams: 'teams_88ddd40a',
  welcome: 'welcome_88ddd40a',
  welcomeImage: 'welcomeImage_88ddd40a',
  links: 'links_88ddd40a'
};

export default styles;
/* tslint:enable */