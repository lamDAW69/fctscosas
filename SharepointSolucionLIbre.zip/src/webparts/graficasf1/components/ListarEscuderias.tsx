import * as React from "react";
//  import { IListsAlumnos } from "./ITodoProps";
import { IViewField, ListView, SelectionMode } from "@pnp/spfx-controls-react";

import { PanelEscuderia } from "./PanelEscuderia";

import { getSP } from "../pnpjsConfig";
import { SPFI } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import { DialogEscuderia } from "./PanelAgregarEscuderia";
// import EscuderiasGraficas from "./EscuderiasGraficas";
import EscuderiasGraficas2 from "./EscuderiasGraficas2";


interface IListarEscuderias {
  nombreLista: string;
}

const ListarEscuderias: React.FC<IListarEscuderias> = ({ nombreLista }) => {
  const [isPanelOpen, setIsPanelOpen] = React.useState(false);
  const [item, setItem] = React.useState<any[]>([]);
  console.log(item);
  const _sp: SPFI = getSP();

  const [escuderias, setEscuderias] = React.useState<any>([]);

  async function ReadData() {
    const items: any[] = await _sp.web.lists.getByTitle(nombreLista).items();
    console.log(items);
    setEscuderias(items);
    setIsPanelOpen(false);
  }

  React.useEffect(() => {
    if (!isPanelOpen) {
      ReadData();
    }
  }, []);

  function _getSelection(items: any[]) {
    console.log("Selected items: ", items);
    setItem(items);
    setIsPanelOpen(!isPanelOpen);
  }

  const viewFields: IViewField[] = [
    {
      name: "ID",
      displayName: "ID",
      minWidth: 50,
      maxWidth: 100,
      isResizable: true,
    },
    {
      name: "Title",
      displayName: "Nombre",
      minWidth: 150,
      maxWidth: 300,
      isResizable: true,
    },
    {
      name: "N_x00ba_CAMPEONATOSGANADOS",
      displayName: "Campeonatos",
      minWidth: 120,
      maxWidth: 220,
      isResizable: true,
    },
    {
      name: "N_x00ba_DEVICTORIASGP",
      displayName: "Victorias",
      minWidth: 80,
      maxWidth: 120,
      isResizable: true,
    },
    {
      name: "PROBABILIDADESDEGANARUNGP",
      displayName: "Probabilidad",
      minWidth: 100,
      maxWidth: 180,
      isResizable: true,
    },
    {
      name: "POLE",
      displayName: "POLE",
      minWidth: 50,
      maxWidth: 100,
      isResizable: true,
    },
    {
      name: "P_x00d3_DIUMS",
      displayName: "Podiums",
      minWidth: 80,
      maxWidth: 150,
      isResizable: true,
    },
    {
      name: "GPENLOSQUEHAPARTICIPADO",
      displayName: "Asistencia",
      minWidth: 100,
      maxWidth: 200,
      isResizable: true,
    }
  ];

  return (
    <>
    <DialogEscuderia refreshList={ReadData}/>
      <ListView
        items={escuderias}
        viewFields={viewFields}
        iconFieldName="AccountBrowserIcon"
        compact={true}
        selection={_getSelection}
        selectionMode={SelectionMode.single}
        showFilter={true}
        stickyHeader={true}
      />
       {isPanelOpen &&
  <PanelEscuderia open={isPanelOpen} data={item} refresh={ReadData}/>
  } 
  {/* <EscuderiasGraficas datos = {escuderias} /> */}
    
    <EscuderiasGraficas2  datos={escuderias} />
    </>
  );
};

export default ListarEscuderias;
