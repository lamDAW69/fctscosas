import * as React from 'react';
import {
  
  MultiStackedBarChart,
  IChartProps,
  MultiStackedBarChartVariant,
} from '@fluentui/react-charting';

interface IMSBCVariantExampleState {
  hideLabels: boolean;
}

interface IMultiStackedBarChartProps {
    datos: any[]; // Suponiendo que tus datos de SharePoint son de tipo array
}

export class MultiStackedBarChartVariantExample extends React.Component<IMultiStackedBarChartProps, IMSBCVariantExampleState> {
  constructor(props : IMultiStackedBarChartProps) {
    super(props);

    this.state = {
      hideLabels: true,
    };
  }

  public render() {
    const { datos } = this.props;

    // Procesar los datos para adaptarlos al formato necesario para el gráfico de barras apiladas múltiples
    const chartData: IChartProps[] = datos.map((item: any) => ({
        chartTitle: item.Title,
        chartData: [
            { legend: 'Campeonatos', data: item.N_x00ba_CAMPEONATOSGANADOS, color: '#bd4f39' },
            { legend: 'Victorias', data: item.N_x00ba_DEVICTORIASGP, color: '#98ff61' },
            { legend: 'Probabilidad', data: item.PROBABILIDADESDEGANARUNGP, color: '#182345' },
            { legend: 'POLE', data: item.POLE, color: '#3fab70' },
            { legend: 'Podiums', data: item.P_x00d3_DIUMS, color: '#8c7f6c' },
            { legend: 'Asistencia', data: item.GPENLOSQUEHAPARTICIPADO, color: '#aec4f2' }
        ],
    }));


    return (
        <>
        
          <MultiStackedBarChart
            data={chartData}
            variant={MultiStackedBarChartVariant.AbsoluteScale}
            hideLabels={this.state.hideLabels}
          />
        </>
      );
    }

    }

    export default MultiStackedBarChartVariantExample;