import * as React from 'react';
import {
    DonutChart,
    IChartProps,
    IChartDataPoint,
    DataVizPalette,
    getColorFromToken,
  } from '@fluentui/react-charting';
   
interface IDonutProps {
    datos: any[]; // Suponiendo que tus datos de SharePoint son de tipo array
}
 
const Donut: React.FC<IDonutProps> = ({ datos }) => {
    const [dynamicData, setDynamicData] = React.useState<IChartDataPoint[]>([]);
 
    React.useEffect(() => {
        // Procesar los datos para adaptarlos al formato necesario para el gráfico de donut
        const data: IChartDataPoint[] = datos.map((item: any) => ({
            legend: item.Title,
            data: item.N_x00ba_CAMPEONATOSGANADOS,
            color: getColorFromToken(DataVizPalette.color1)
        }));
 
        setDynamicData(data);
    }, [datos]);
 
    const data: IChartProps = {
        chartTitle: 'Donut chart dynamic example',
        chartData: dynamicData,
    };
 
    return (
        <DonutChart
            data={data}
            innerRadius={35}
            legendProps={{ allowFocusOnLegends: true }}
            hideLabels={false}
            showLabelsInPercent={true}
        />
    );
};
 
export default Donut;