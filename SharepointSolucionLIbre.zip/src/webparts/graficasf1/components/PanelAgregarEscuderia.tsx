import * as React from 'react';
import {Dialog, DialogFooter } from '@fluentui/react/lib/Dialog';
import { ActionButton } from '@fluentui/react';

import{useId, useBoolean} from '@fluentui/react-hooks';
import {SPFI} from '@pnp/sp';
import {getSP} from '../pnpjsConfig';
import {Stack, IStackProps, IStackStyles} from "@fluentui/react/lib/Stack";
import { IIconProps } from '@fluentui/react';
import { TextField } from "@fluentui/react";
const stackTokens = {childrenGap: 50};
const stackStyles : Partial<IStackStyles> = {root: {width :650}};
const columnProps : Partial<IStackProps> = {
    tokens: {childrenGap: 15},
    styles: {root: {width:300}},
};

const addFriendIcon : IIconProps = {iconName: "AddFriend"};

const dialogStyles = {main: {width : 650}};

interface IPop {
    refreshList:() => void;
}

export const DialogEscuderia: React.FunctionComponent<IPop> = ({refreshList}) => {
    const [hideDialog, {toggle: toggleHideDialog}] = useBoolean(true);

    const labelId: string = useId('dialogLabel');
    const subTextId: string = useId('subTextLabel');
    const _sp: SPFI = getSP();
    const list = _sp.web.lists.getByTitle("Escuderias");

    const modelProps = React.useMemo (() => ({
        titleAriaId: labelId,
        subtitleAriaId: subTextId,
        isBlocking: false,
        styles: dialogStyles,
    }), 
    [labelId, subTextId]
    );
    
    const [escuderia, setEscuderia] = React.useState({
        Title: "",
        N_x00ba_CAMPEONATOSGANADOS: "",
        N_x00ba_DEVICTORIASGP: "",
        POLE: "",
        PROBABILIDADESDEGANARUNGP: "",
        P_x00d3_DIUMS: "",
        GPENLOSQUEHAPARTICIPADO: ""
    });

    const handlerChange = (
        e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
      ) => {
        const { value, id } = e.target;
        console.log(e.target);
        setEscuderia((prevState) => ({
          ...prevState,
          [id.trim()]: value,
        }));
      };

    const handlerSave = async () => {
   
        const iar = await list.items.add({
          Title: escuderia.Title,
          N_x00ba_CAMPEONATOSGANADOS: escuderia.N_x00ba_CAMPEONATOSGANADOS,
          N_x00ba_DEVICTORIASGP: escuderia.N_x00ba_DEVICTORIASGP,
          PROBABILIDADESDEGANARUNGP: escuderia.PROBABILIDADESDEGANARUNGP,
          POLE: escuderia.POLE,
          P_x00d3_DIUMS: escuderia.P_x00d3_DIUMS,
          GPENLOSQUEHAPARTICIPADO: escuderia.GPENLOSQUEHAPARTICIPADO,
        });
        // refreshList();
        console.log(iar);
        toggleHideDialog();
    };

    return (
        <>
        <ActionButton iconProps={addFriendIcon} onClick={toggleHideDialog}>
            Agregar Escuderia
        </ActionButton>
        
        <Dialog
            hidden = {hideDialog}
            onDismiss={toggleHideDialog}

            modalProps={modelProps}
        >
            <Stack horizontal tokens={stackTokens} styles={stackStyles}>
                <Stack {...columnProps}>
                    <TextField
                        label="Nombre"
                        id="Title"
                        onChange={handlerChange}
                        />
                        <TextField
                        label="Campeonatos"
                        id="N_x00ba_CAMPEONATOSGANADOS"
                        onChange={handlerChange}
                        />
                        <TextField
                        label="Victorias"
                        id="N_x00ba_DEVICTORIASGP"
                        onChange={handlerChange}
                        />
                        <TextField
                        label="WinRate"
                        id="PROBABILIDADESDEGANARUNGP"
                        onChange={handlerChange}
                        />
                        <TextField
                        label="POLE"
                        id="POLE"
                        onChange={handlerChange}
                        />
                        <TextField
                        label="Podiums"
                        id="P_x00d3_DIUMS"
                        onChange={handlerChange}
                        />
                        <TextField
                        label="Asistencia"
                        id="GPENLOSQUEHAPARTICIPADO"
                        onChange={handlerChange}
                        />

                </Stack>
            </Stack>
            <DialogFooter>
                <ActionButton iconProps={addFriendIcon} onClick={handlerSave}>Guardar</ActionButton>
            </DialogFooter>
        </Dialog>
        </>
    )

}