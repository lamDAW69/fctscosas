import * as React from "react";
import type { IGraficasf1Props } from "./IGraficasf1Props";

//LIbrerías pnp
import ListarEscuderias from "./ListarEscuderias";
// import EscuderiasGraficas from "./EscuderiasGraficas";
// import EscuderiasGraficas2 from "./EscuderiasGraficas2";

const Todo: React.FC<IGraficasf1Props> = (props) => {
  const { description } = props;

  return (
    <>
      <ListarEscuderias nombreLista={description} />
      {/* <EscuderiasGraficas datos = {[]} /> */}
      {/* <EscuderiasGraficas2 datos = {[]} /> */}
    </>
  );
};

export default Todo;
