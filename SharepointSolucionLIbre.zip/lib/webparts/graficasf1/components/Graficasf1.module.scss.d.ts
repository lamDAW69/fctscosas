declare const styles: {
    graficasf1: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=Graficasf1.module.scss.d.ts.map