export interface IGraficasf1Props {
    description: string;
}
export interface IGraficasf1 {
    ID?: number;
    Title: string;
    N_x00ba_CAMPEONATOSGANADOS?: number;
    N_x00ba_DEVICTORIASGP?: number;
    PROBABILIDADESDEGANARUNGP?: number;
    POLE?: number;
    P_x00d3_DIUMS?: number;
    GPENLOSQUEHAPARTICIPADO: number;
}
//# sourceMappingURL=IGraficasf1Props.d.ts.map