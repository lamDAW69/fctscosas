import * as React from 'react';
interface IMSBCVariantExampleState {
    hideLabels: boolean;
}
interface IMultiStackedBarChartProps {
    datos: any[];
}
export declare class MultiStackedBarChartVariantExample extends React.Component<IMultiStackedBarChartProps, IMSBCVariantExampleState> {
    constructor(props: IMultiStackedBarChartProps);
    render(): JSX.Element;
}
export default MultiStackedBarChartVariantExample;
//# sourceMappingURL=EscuderiasGraficas2.d.ts.map