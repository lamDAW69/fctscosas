import * as React from "react";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
interface IPanelReact {
    open: boolean;
    data: any[];
    refresh: () => void;
}
export declare const PanelEscuderia: React.FC<IPanelReact>;
export {};
//# sourceMappingURL=PanelEscuderias.d.ts.map