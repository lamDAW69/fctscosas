import * as React from 'react';
interface IDonutProps {
    datos: any[];
}
declare const Donut: React.FC<IDonutProps>;
export default Donut;
//# sourceMappingURL=EscuderiasGraficas.d.ts.map