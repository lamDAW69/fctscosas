import * as React from "react";
import type { IGraficasf1Props } from "./IGraficasf1Props";
declare const Todo: React.FC<IGraficasf1Props>;
export default Todo;
//# sourceMappingURL=Graficasf1.d.ts.map