import * as React from "react";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
interface IListarEscuderias {
    nombreLista: string;
}
declare const ListarEscuderias: React.FC<IListarEscuderias>;
export default ListarEscuderias;
//# sourceMappingURL=ListarEscuderias.d.ts.map