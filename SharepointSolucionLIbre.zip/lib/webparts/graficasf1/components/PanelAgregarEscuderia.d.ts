import * as React from 'react';
interface IPop {
    refreshList: () => void;
}
export declare const DialogEscuderia: React.FunctionComponent<IPop>;
export {};
//# sourceMappingURL=PanelAgregarEscuderia.d.ts.map