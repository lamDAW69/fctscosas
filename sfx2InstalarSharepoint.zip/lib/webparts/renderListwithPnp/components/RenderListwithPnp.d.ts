/// <reference types="react" />
import type { IRenderListwithPnpProps } from "./IRenderListwithPnpProps";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
declare const RenderListwithPnp: (props: IRenderListwithPnpProps) => JSX.Element;
export default RenderListwithPnp;
//# sourceMappingURL=RenderListwithPnp.d.ts.map