declare const styles: {
    renderListwithPnp: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=RenderListwithPnp.module.scss.d.ts.map