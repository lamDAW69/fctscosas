import { Version } from '@microsoft/sp-core-library';
import { type IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IRenderListwithPnpWebPartProps {
    listName: string;
}
export default class RenderListwithPnpWebPart extends BaseClientSideWebPart<IRenderListwithPnpWebPartProps> {
    render(): void;
    protected onInit(): Promise<void>;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=RenderListwithPnpWebPart.d.ts.map