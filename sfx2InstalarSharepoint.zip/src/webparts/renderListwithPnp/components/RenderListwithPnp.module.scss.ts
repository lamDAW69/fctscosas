/* tslint:disable */
require("./RenderListwithPnp.module.css");
const styles = {
  renderListwithPnp: 'renderListwithPnp_076fe0ff',
  teams: 'teams_076fe0ff',
  welcome: 'welcome_076fe0ff',
  welcomeImage: 'welcomeImage_076fe0ff',
  links: 'links_076fe0ff'
};

export default styles;
/* tslint:enable */