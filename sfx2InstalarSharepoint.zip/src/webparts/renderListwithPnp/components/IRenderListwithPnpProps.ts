export interface IRenderListwithPnpProps {
  listName: string;
  ctx : any
}

export interface IListsAlumnos {
  ID: number;
  DNI: string;
  Nombre: string;
  Apellido: string;
  Edad: number;
  Foto: string; 
}
