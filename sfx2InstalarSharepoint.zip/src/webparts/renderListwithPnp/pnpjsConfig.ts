import { WebPartContext } from "@microsoft/sp-webpart-base";

import { SPFI, spfi, SPFx } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/batching";

// eslint-disable-next-line no-var
let _sp: SPFI; // Cambiado SPFI por sp
export const getSP = (context?: WebPartContext): SPFI => {
 if (!!context){
    // Debes importar SPFx para utilizarlo
    _sp = spfi().using(SPFx(context)).using();; // Cambiado spfi() por sp.configure() y PnPLoggin por PnPLogging
 }

 return _sp;

};
