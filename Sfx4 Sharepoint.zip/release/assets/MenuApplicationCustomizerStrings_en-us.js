define([], function() {
  return {
    "Title": "MenuApplicationCustomizer"
  }
});