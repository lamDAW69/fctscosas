declare interface IMenuApplicationCustomizerStrings {
  Title: string;
}

declare module 'MenuApplicationCustomizerStrings' {
  const strings: IMenuApplicationCustomizerStrings;
  export = strings;
}
