export default function PrimarySearchAppBar(): JSX.Element;
//# sourceMappingURL=MenuTop.d.ts.map